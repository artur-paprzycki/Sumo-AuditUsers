import json
import requests
import datetime
import os
import boto3
from base64 import b64decode
from mainfunc import *


def lambda_handler(event, context):
    # TODO implement
    return rightNow(),dothework()
    
