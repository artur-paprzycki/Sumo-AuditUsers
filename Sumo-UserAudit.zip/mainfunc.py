import json
import requests
import datetime
import os
import boto3
from base64 import b64decode

class SumoLogic(object):

    def __init__(self, accessId, accessKey, endpoint):
        self.session = requests.Session()
        self.session.auth = (accessId, accessKey)
        self.session.headers = {'content-type': 'application/json', 'accept': 'application/json'}
        if endpoint is None:
            self.endpoint = self._get_endpoint()
        else:
            self.endpoint = endpoint

    def _get_endpoint(self):
        self.endpoint = 'https://api.eu.sumologic.com/api/v1/'
        self.response = self.session.get('https://api.eu.sumologic.com/api/v1/collectors')  # Dummy call to get endpoint
        endpoint = self.response.url.replace('/collectors', '')  # dirty hack to sanitise URI and retain domain
        return endpoint

    def delete(self, method, params=None):
        r = self.session.delete(self.endpoint + method, params=params)
        r.raise_for_status()
        return r

    def get(self, method, params=None):
        r = self.session.get(self.endpoint + method, params=params)
        if 400 <= r.status_code < 600:
            r.reason = r.text
        r.raise_for_status()
        return r

    def post(self, method, params, headers=None):
        r = self.session.post(self.endpoint + method, data=json.dumps(params), headers=headers)
        r.raise_for_status()
        return r

    def put(self, method, params, headers=None):
        r = self.session.put(self.endpoint + method, data=json.dumps(params), headers=headers)
        r.raise_for_status()
        return r

    def getallusers(self, limit=None, offset=None):
        params = {'limit': limit, 'offset': offset}
        r = self.get('users/', params)
        return json.loads(r.text)['data']

    def delete_user(self, user):
        return self.delete('users/' + str(user))

    def update_user(self, user_id, user):
        return self.put('users/' + str(user_id), user)
    #get ID in a different var


#mysumo = SumoLogic(os.environ['usrapi'],os.environ['pasapi'],os.environ['lnkapi'])

def decryptcreds():
    global ENCRYPTED_USR
    global DECRYPTED_USR
    global ENCRYPTED_PAS
    global DECRYPTED_PAS
    ENCRYPTED_USR = os.environ['usrapi']
    DECRYPTED_USR = boto3.client('kms').decrypt(CiphertextBlob=b64decode(ENCRYPTED_USR))['Plaintext']
    ENCRYPTED_PAS = os.environ['pasapi']
    DECRYPTED_PAS = boto3.client('kms').decrypt(CiphertextBlob=b64decode(ENCRYPTED_PAS))['Plaintext']

def rightNow():
    global mylocaldays
    mylocaldateepoch = datetime.datetime.now().timestamp()
    mylocaldays = (((mylocaldateepoch / 60)/60)/24)
    return mylocaldateepoch

def dothework():
    decryptcreds()
    mysumo = SumoLogic(DECRYPTED_USR,DECRYPTED_PAS,os.environ['lnkapi'])
    for i in mysumo.getallusers():
        if (i['isActive'] == False):
            print(f"User {i['firstName']} {i['lastName']} already deactivated")
        elif (i['lastLoginTimestamp']) == None:
            print(f"User {i['firstName']} {i['lastName']} has not logged in at all")
        elif ((i['firstName']) == 'Service') or ((i['firstName']) == 'SumoLogic') or ((i['firstName']) == 'Admin') or ((i['firstName']) == 'service'):
            print(f"User {i['firstName']} {i['lastName']} whitelisted")
            #skip to next function
        # User lockout alert
        #elif i['isLocked'] == True:
        #    print(f"User {i['firstName']} {i['lastName']} has locked account!")
        else:
            utc_time = datetime.datetime.strptime([i][0]['lastLoginTimestamp'], "%Y-%m-%dT%H:%M:%S.%fZ")
            epoch_time12 = (utc_time - datetime.datetime(1970, 1, 1)).total_seconds()
            days = (((epoch_time12 / 60)/60)/24)
            if mylocaldays - days > 90:
                howMany = mylocaldays - days
                howMany = round(howMany)
                print(f"User {[i][0]['firstName']} {[i][0]['lastName']} hasn't logged in in the past 90 days ({howMany} days)")
                if [i][0]['isActive'] == True:
                    #print(f"User {[i][0]['firstName']} {[i][0]['lastName']} will be deactivated")
                    userID = i['id']
                    toChangeVar = i
                    toChangeVar['isActive'] = False
                    del toChangeVar['email'],toChangeVar['createdAt'],toChangeVar['createdBy'],toChangeVar['modifiedAt']
                    del toChangeVar['modifiedBy'],toChangeVar['id'],toChangeVar['isLocked'],toChangeVar['lastLoginTimestamp']
                    # mysumo.update_user(userID, toChangeVar)
                    print(f"User {[i][0]['firstName']} {[i][0]['lastName']} has been deactivated")
                else:
                    #print('No changes were made')
                    pass
    print('function complete')